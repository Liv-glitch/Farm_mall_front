"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calculator, TrendingUp, Loader2, Lock } from "lucide-react"
import type { CropVariety } from "@/lib/types/production"
import { POTATO_VARIETIES } from "@/lib/data/potato-varieties"

export function CostCalculatorPublic() {
  const [cropVarieties, setCropVarieties] = useState<CropVariety[]>([])
  const [loadingVarieties, setLoadingVarieties] = useState(true)
  const [landSize, setLandSize] = useState("")
  const [cropVarietyId, setCropVarietyId] = useState("")
  const [seedSize, setSeedSize] = useState<1 | 2>(1)
  const [showResults, setShowResults] = useState(false)
  const [calculatedCost, setCalculatedCost] = useState(0)
  const [seedRequirement, setSeedRequirement] = useState(0)
  const [usageCount, setUsageCount] = useState(0)
  const [showLimitReached, setShowLimitReached] = useState(false)
  const [costBreakdown, setCostBreakdown] = useState({
    seeds: 0,
    fertilizer: 0,
    herbicides: 0,
    fungicides: 0,
    insecticides: 0,
    labor: 0,
    landPreparation: 0,
    miscellaneous: 0
  })

  const MAX_FREE_USES = 5

  useEffect(() => {
    loadCropVarieties()
    // Load usage count from localStorage
    const savedUsageCount = localStorage.getItem('farm_mall_calculator_uses')
    const count = savedUsageCount ? parseInt(savedUsageCount, 10) : 0
    setUsageCount(count)
  }, [])

  const loadCropVarieties = async () => {
    try {
      setLoadingVarieties(true)

      setCropVarieties(POTATO_VARIETIES)
    } catch (error: any) {
      console.error('Failed to load crop varieties:', error)
      setCropVarieties([])
    } finally {
      setLoadingVarieties(false)
    }
  }

  const calculateCost = () => {
    // Check usage limit
    if (usageCount >= MAX_FREE_USES) {
      setShowLimitReached(true)
      return
    }

    const size = Number.parseFloat(landSize) || 0
    const selectedVariety = cropVarieties.find(v => v.id === cropVarietyId)

    if (!selectedVariety) {
      alert("Please select a crop variety")
      return
    }

    const bagsPerAcre = seedSize === 1 ? selectedVariety.seedSize1BagsPerAcre : selectedVariety.seedSize2BagsPerAcre
    const seedCostPerAcre = seedSize === 1 ? selectedVariety.seedSize1CostPerAcre : selectedVariety.seedSize2CostPerAcre

    const breakdown = {
      seeds: seedCostPerAcre * size,
      fertilizer: selectedVariety.fertilizerCostPerAcre * size,
      herbicides: selectedVariety.herbicideCostPerAcre * size,
      fungicides: selectedVariety.fungicideCostPerAcre * size,
      insecticides: selectedVariety.insecticideCostPerAcre * size,
      labor: selectedVariety.laborCostPerAcre * size,
      landPreparation: selectedVariety.landPreparationCostPerAcre * size,
      miscellaneous: selectedVariety.miscellaneousCostPerAcre * size
    }

    const total = Object.values(breakdown).reduce((sum, cost) => sum + cost, 0)
    const seeds = size * bagsPerAcre

    setCalculatedCost(total)
    setSeedRequirement(seeds)
    setCostBreakdown(breakdown)
    setShowResults(true)

    // Increment and save usage count
    const newUsageCount = usageCount + 1
    setUsageCount(newUsageCount)
    localStorage.setItem('farm_mall_calculator_uses', newUsageCount.toString())
  }

  const resetCalculator = () => {
    setLandSize("")
    setCropVarietyId("")
    setSeedSize(1)
    setShowResults(false)
    setCalculatedCost(0)
    setSeedRequirement(0)
    setCostBreakdown({
      seeds: 0,
      fertilizer: 0,
      herbicides: 0,
      fungicides: 0,
      insecticides: 0,
      labor: 0,
      landPreparation: 0,
      miscellaneous: 0
    })
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Production Details */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        <Card className="h-full border-0 shadow-lg bg-white">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Calculator className="w-5 h-5 text-sage-700" />
              <span>Calculate Your Costs</span>
            </CardTitle>
            <p className="text-sm text-gray-600">Enter your farm details to get accurate cost estimates</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="cropType">Crop Variety</Label>
              {loadingVarieties ? (
                <div className="h-12 flex items-center justify-center border rounded-md">
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  <span className="text-sm">Loading varieties...</span>
                </div>
              ) : (
                <Select value={cropVarietyId} onValueChange={setCropVarietyId}>
                  <SelectTrigger className="h-12">
                    <SelectValue placeholder="Select crop variety" />
                  </SelectTrigger>
                  <SelectContent>
                    {cropVarieties.length > 0 ? (
                      cropVarieties.map((variety) => (
                        <SelectItem key={variety.id} value={variety.id}>
                          {variety.name}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-varieties" disabled>
                        No varieties available
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div>
              <Label htmlFor="landSize">Farm Size (Acres)</Label>
              <Input
                id="landSize"
                type="number"
                placeholder="Enter acreage"
                value={landSize}
                onChange={(e) => setLandSize(e.target.value)}
                className="h-12"
              />
            </div>

            <div>
              <Label htmlFor="seedSize">Seed Size</Label>
              <Select value={seedSize.toString()} onValueChange={(value) => setSeedSize(Number(value) as 1 | 2)}>
                <SelectTrigger className="h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cropVarietyId && (() => {
                    const selectedVariety = cropVarieties.find(v => v.id === cropVarietyId)
                    return selectedVariety ? (
                      <>
                        <SelectItem value="1">Size 1 ({selectedVariety.seedSize1BagsPerAcre} bags per acre)</SelectItem>
                        <SelectItem value="2">Size 2 ({selectedVariety.seedSize2BagsPerAcre} bags per acre)</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="1">Size 1</SelectItem>
                        <SelectItem value="2">Size 2</SelectItem>
                      </>
                    )
                  })() || (
                      <>
                        <SelectItem value="1">Size 1</SelectItem>
                        <SelectItem value="2">Size 2</SelectItem>
                      </>
                    )}
                </SelectContent>
              </Select>
            </div>

            <Button
              onClick={calculateCost}
              className="w-full h-12 bg-sage-700 hover:bg-sage-800 text-white"
              disabled={!landSize || !cropVarietyId || loadingVarieties}
            >
              Calculate Costs {usageCount > 0 && `(${MAX_FREE_USES - usageCount} uses left)`}
            </Button>

            {showResults && (
              <Button onClick={resetCalculator} variant="outline" className="w-full h-12 bg-transparent">
                Reset Calculator
              </Button>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Cost Breakdown */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        whileInView={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        viewport={{ once: true }}
      >
        <Card className="h-full border-0 shadow-lg bg-white">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-warm-600" />
              <span>Cost Breakdown</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              {showResults ? (() => {
                const selectedVariety = cropVarieties.find(v => v.id === cropVarietyId)
                return selectedVariety ? `Estimated costs for ${selectedVariety.name}` : "Cost breakdown"
              })() : "Results will appear here"}
            </p>
          </CardHeader>
          <CardContent>
            {showResults ? (
              <div className="space-y-6">
                <div className="text-center p-6 bg-gradient-to-br from-sage-50 to-warm-50 rounded-xl border border-sage-100">
                  <div className="text-sm text-gray-600 mb-1">Total Production Cost</div>
                  <div className="text-3xl font-bold text-sage-700">KSh {calculatedCost.toLocaleString()}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Cost per acre: KSh {Math.round(calculatedCost / Number.parseFloat(landSize)).toLocaleString()}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-sage-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-sage-600 rounded-full"></div>
                      <span className="text-sm font-medium">Seeds</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.seeds.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">{seedRequirement} bags total</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-warm-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-warm-600 rounded-full"></div>
                      <span className="text-sm font-medium">Fertilizer</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.fertilizer.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-sage-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-sage-600 rounded-full"></div>
                      <span className="text-sm font-medium">Herbicides</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.herbicides.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-warm-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-warm-600 rounded-full"></div>
                      <span className="text-sm font-medium">Fungicides</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.fungicides.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-sage-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-sage-600 rounded-full"></div>
                      <span className="text-sm font-medium">Insecticides</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.insecticides.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-warm-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-warm-600 rounded-full"></div>
                      <span className="text-sm font-medium">Labor</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.labor.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-sage-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-sage-600 rounded-full"></div>
                      <span className="text-sm font-medium">Land Preparation</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.landPreparation.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Total cost</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-warm-50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-warm-600 rounded-full"></div>
                      <span className="text-sm font-medium">Other Costs</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">KSh {costBreakdown.miscellaneous.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Miscellaneous</div>
                    </div>
                  </div>
                </div>

                <div className="text-center pt-4 border-t border-gray-100">
                  <p className="text-sm text-gray-600 mb-3">
                    {usageCount >= MAX_FREE_USES - 1
                      ? "This was your last free calculation!"
                      : "Want detailed breakdown and planning tools?"
                    }
                  </p>
                  <Button className="bg-sage-700 hover:bg-sage-800 text-white">
                    Sign Up for Full Access
                  </Button>
                </div>
              </div>
            ) : showLimitReached ? (
              <div className="text-center py-12">
                <Lock className="w-12 h-12 mx-auto mb-4 text-sage-600" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Free Usage Limit Reached</h3>
                <p className="text-gray-600 mb-4">
                  You've used all {MAX_FREE_USES} free calculations. Sign up to get unlimited access plus:
                </p>
                <ul className="text-left text-sm text-gray-600 mb-6 space-y-1">
                  <li>• Unlimited cost calculations</li>
                  <li>• Harvest forecasting</li>
                  <li>• Production cycle tracking</li>
                  <li>• Profit analysis tools</li>
                  <li>• Farm management dashboard</li>
                </ul>
                <div className="space-y-2">
                  <Link href="/auth/register">
                    <Button className="w-full bg-sage-700 hover:bg-sage-800 text-white">
                      Sign Up for Free
                    </Button>
                  </Link>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      localStorage.removeItem('farm_mall_calculator_uses')
                      setUsageCount(0)
                      setShowLimitReached(false)
                    }}
                  >
                    Reset (Demo Only)
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Calculator className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Enter your production details to see cost estimates</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
